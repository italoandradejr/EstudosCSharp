using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoIptu.Views.Shared
{
    public class _MenuModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
