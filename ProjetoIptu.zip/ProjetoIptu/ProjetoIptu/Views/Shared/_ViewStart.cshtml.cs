using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProjetoIptu.Views.Shared
{
    public class _ViewStartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
