﻿namespace ProjetoIptu.Views.Shared
{
    public class _Layout
    {
    }
}
